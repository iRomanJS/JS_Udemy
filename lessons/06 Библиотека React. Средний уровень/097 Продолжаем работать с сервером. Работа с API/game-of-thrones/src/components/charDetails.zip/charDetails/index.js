import CharDetails, {Field} from './charDetails';
export {Field};
export default CharDetails;
